﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace RCOBLabManagement.Models
{
    public class UserModel
    {

        public int SubjectID { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        //[DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [DataType(DataType.Password)]
        //[StringLength(40, MinimumLength = 7, ErrorMessage = "Password must be between 7-40 characters.")]
        public string Password { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [Compare("Password", ErrorMessage = "Passwords do not match.")]
        [Display(Name = "Confirm Password")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [Display(Name = "First Name")]

        public string FirstName { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [Display(Name = "Last Name")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        public string Gender { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [Display(Name = "Date of Birth")]
        [DataType(DataType.Date)]
        public string DOB { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        public string Major { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [Display(Name = "Enrollment Date")]
        [DataType(DataType.Date)]
        public string EnrollmentDate { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        public Decimal GPA { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        public string Address { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        public string ZIP { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [Display(Name = "Payment Type")]
        public string PayType { get; set; }

        [Required(ErrorMessage = "This field is required.")]
        [Display(Name = "Payment Info")]
        public string PayInfo { get; set; }




    }
}
