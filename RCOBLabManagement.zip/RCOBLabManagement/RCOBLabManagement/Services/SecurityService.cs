﻿using RCOBLabManagement.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace RCOBLabManagement.Services
{
    public class SecurityService
    {

        UserDAO usersDAO = new UserDAO();

        public SecurityService()
        {
            

        }

        public bool IsValid(UserModel user)
        {
            return usersDAO.FindUserByNameAndPassword(user);
        }
    }
}
