﻿using RCOBLabManagement.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace RCOBLabManagement.Services
{
    public class UserDAO
    {

        string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\pierce.roark\Desktop\School\Fall_2021\CS_483\RCOBLabManagement\RCOBLabManagement\dbo\App_Data\Database1.mdf;Integrated Security=True";
        SqlDataReader reader;
        public bool FindUserByNameAndPassword(UserModel user)
        {

            bool success = false;

            string sqlStatement = "SELECT * FROM dbo.[User] WHERE SubjectID = @SubjectID AND FirstName = @Email AND Password = @Password";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {

                SqlCommand command = new SqlCommand(sqlStatement, connection);

                command.Parameters.Add("@Email", System.Data.SqlDbType.VarChar, 40).Value = user.Email;
                command.Parameters.Add("@Password", System.Data.SqlDbType.VarChar, 40).Value = user.Password;
                

                try
                {
                    connection.Open();
                    reader = command.ExecuteReader();
                    if (reader.HasRows)
                    {
                        success = true;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }

            }

            return success;

        }
    }
}
